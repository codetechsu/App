package com.example.sokratech;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sokratech.R;

public class Freshman extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.freshmanlayout);
        init();
    }
    private void init(){}
}
