package com.example.sokratech;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    private EditText username, password;
    private Button btnRegister, btnGoToLogin;
    private EditText name, surname;
    private FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registerlayout);
        init();
    }

    public void init()
    {
        auth = FirebaseAuth.getInstance();
        username = (EditText) findViewById(R.id.usernameRegister);
        password = (EditText) findViewById(R.id.passwordRegister);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnGoToLogin = (Button) findViewById(R.id.btnGoToLogin);
        name = (EditText) findViewById(R.id.Name);
        surname = (EditText) findViewById(R.id.Surname);

        btnRegister.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String txtusername = username.getText().toString();
                String txtpassword = password.getText().toString();
                String txtName = name.getText().toString();
                String txtSurname = surname.getText().toString();
                if (TextUtils.isEmpty(txtusername))
                {
                    Toast.makeText(RegisterActivity.this,   "Email cannot be empty",Toast.LENGTH_LONG).show();
                }
                else if (TextUtils.isEmpty(txtpassword))
                {
                    Toast.makeText(RegisterActivity.this,   "Password cannot be empty",Toast.LENGTH_LONG).show();
                }
                else if (txtpassword.length() < 8)
                {
                    Toast.makeText(RegisterActivity.this,   "Password cannot be less than 8 characters",Toast.LENGTH_LONG).show();
                }
                else {
                    auth.createUserWithEmailAndPassword(txtusername, txtpassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful())
                            {
                                Toast.makeText(RegisterActivity.this, "Account creation is successfull", Toast.LENGTH_LONG).show();
                                Intent loginintent = new Intent(RegisterActivity.this, LoginActivity.class);
                                startActivity(loginintent);
                                finish();
                            }
                            else
                            {
                                Toast.makeText(RegisterActivity.this, "There is a mistake", Toast.LENGTH_LONG).show();

                            }

                        }
                    });

                    Toast.makeText(RegisterActivity.this, "Register successful", Toast.LENGTH_SHORT).show();

                }
            }


    }
);
    btnGoToLogin.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent login = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(login);
            finish();

        }
    });

    }


}


