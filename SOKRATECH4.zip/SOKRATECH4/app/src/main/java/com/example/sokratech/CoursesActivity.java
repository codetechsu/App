package com.example.sokratech;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CoursesActivity extends AppCompatActivity {

        private Button btnFreshman, btnCs, btnMath, btnEcon;
        private TextView courses;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.courseslayout);
            init();
        }



        private void init(){
            btnFreshman = (Button)  findViewById(R.id.freshman);
            btnCs = (Button)  findViewById(R.id.cs);
            btnMath = (Button)  findViewById(R.id.math);
            btnEcon = (Button)  findViewById(R.id.econ);
        }


}

